﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practico3
{
    public partial class PequeñoFormulario : Form
    {
        public PequeñoFormulario()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void TDni_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite sólo números y la tecla de retroceso (Backspace)
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Desactiva la tecla si no es válida
            }
        }
        private void TApellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite sólo letras, espacios y la tecla de retroceso (Backspace)
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Desactiva la tecla si no es válida
            }
        }

        private void TNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite sólo letras, espacios y la tecla de retroceso (Backspace)
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true; // Desactiva la tecla si no es válida
            }
        }

        private void TGuardar_Click(object sender, EventArgs e)
        {
            // Verificar si alguno de los campos está vacío
            if (string.IsNullOrWhiteSpace(this.TDni.Text) ||
                string.IsNullOrWhiteSpace(this.TNombre.Text) ||
                string.IsNullOrWhiteSpace(this.TApellido.Text))
            {
                // Mostrar mensaje de error
                MessageBox.Show("Debe Completar todos los campos", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Crear la variable ask de tipo DialogResult y asignarle el resultado de un MessageBox
                DialogResult ask = MessageBox.Show("¿Desea guardar los cambios?", "Confirmar Guardado", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // Verificar la respuesta del usuario
                if (ask == DialogResult.Yes)
                {
                    // Si el usuario presiona "Yes", concatenar y mostrar el nombre completo
                    string nombreCompleto = this.TNombre.Text + " " + this.TApellido.Text;
                    this.LModificar.Text = nombreCompleto;
                }
                else
                {
                    // Si el usuario presiona "No", no hacer nada o mostrar otro mensaje
                    MessageBox.Show("El guardado fue cancelado.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            }

        private void TEliminar_Click(object sender, EventArgs e)
        {
            // Verificar si alguno de los campos está vacío
            if (string.IsNullOrWhiteSpace(this.TDni.Text) ||
                string.IsNullOrWhiteSpace(this.TNombre.Text) ||
                string.IsNullOrWhiteSpace(this.TApellido.Text))
            {
                // Mostrar mensaje de advertencia indicando que no hay cliente cargado
                MessageBox.Show("No hay cliente cargado para eliminar.",
                                "Advertencia",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
            }
            else
            {
                // Obtener los datos del cliente para mostrarlos en el mensaje de advertencia
                string cliente = this.TNombre.Text + " " + this.TApellido.Text;

                // Crear la variable ask de tipo DialogResult y asignarle el resultado de un MessageBox
                DialogResult ask = MessageBox.Show($"Está apunto de eliminar el Cliente: {cliente}",
                                                   "Confirmar Eliminación",
                                                   MessageBoxButtons.YesNo,
                                                   MessageBoxIcon.Exclamation,
                                                   MessageBoxDefaultButton.Button2); // Focus en "No"

                // Verificar la respuesta del usuario
                if (ask == DialogResult.Yes)
                {
                    // Si el usuario presiona "Sí", limpiar los TextBox y Label LModificar
                    this.TDni.Clear();
                    this.TNombre.Clear();
                    this.TApellido.Clear();
                    this.LModificar.Text = string.Empty;

                    // Mostrar mensaje de confirmación
                    MessageBox.Show($"El Cliente: {cliente} se eliminó correctamente",
                                    "Eliminar",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);
                }
                // Si el usuario presiona "No", no se realiza ninguna acción
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImage = global::practico3.Properties.Resources.icono_varon;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Cierra la aplicación completa
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.BackgroundImage = global::practico3.Properties.Resources.icono_mujer;

        }
    }
}
