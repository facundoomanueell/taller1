﻿using System.Drawing;

namespace practico3
{
    partial class PequeñoFormulario
    {
        private System.Windows.Forms.Label LTarjeta;
        private System.Windows.Forms.Label LDni;
        private System.Windows.Forms.Label LApellido;
        private System.Windows.Forms.Label LNombre;
        private System.Windows.Forms.Label LNya;
        private System.Windows.Forms.Label LModificar;
        private System.Windows.Forms.TextBox TDni;
        private System.Windows.Forms.TextBox TApellido;
        private System.Windows.Forms.TextBox TNombre;
        private System.Windows.Forms.Button TGuardar;
        private System.Windows.Forms.Button TEliminar;
        private System.Windows.Forms.RadioButton RBVaron;
        private System.Windows.Forms.RadioButton RBMujer;
        private System.Windows.Forms.CheckBox checkBoxNaranja;
        private System.Windows.Forms.CheckBox checkBoxVisa;
        private System.Windows.Forms.CheckBox checkBoxMastercard;


        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.checkBoxNaranja = new System.Windows.Forms.CheckBox();
            this.checkBoxVisa = new System.Windows.Forms.CheckBox();
            this.checkBoxMastercard = new System.Windows.Forms.CheckBox();
            this.LTarjeta = new System.Windows.Forms.Label();
            this.LDni = new System.Windows.Forms.Label();
            this.LNombre = new System.Windows.Forms.Label();
            this.LApellido = new System.Windows.Forms.Label();
            this.LNya = new System.Windows.Forms.Label();
            this.LModificar = new System.Windows.Forms.Label();
            this.TDni = new System.Windows.Forms.TextBox();
            this.TApellido = new System.Windows.Forms.TextBox();
            this.TNombre = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TGuardar = new System.Windows.Forms.Button();
            this.TEliminar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // checkBoxNaranja
            // 
            this.checkBoxNaranja.AutoSize = true;
            this.checkBoxNaranja.Location = new System.Drawing.Point(132, 193);
            this.checkBoxNaranja.Name = "checkBoxNaranja";
            this.checkBoxNaranja.Size = new System.Drawing.Size(77, 20);
            this.checkBoxNaranja.TabIndex = 0;
            this.checkBoxNaranja.Text = "Naranja";
            this.checkBoxNaranja.UseVisualStyleBackColor = true;
            // 
            // checkBoxVisa
            // 
            this.checkBoxVisa.AutoSize = true;
            this.checkBoxVisa.Location = new System.Drawing.Point(132, 223);
            this.checkBoxVisa.Name = "checkBoxVisa";
            this.checkBoxVisa.Size = new System.Drawing.Size(56, 20);
            this.checkBoxVisa.TabIndex = 1;
            this.checkBoxVisa.Text = "Visa";
            this.checkBoxVisa.UseVisualStyleBackColor = true;
            // 
            // checkBoxMastercard
            // 
            this.checkBoxMastercard.AutoSize = true;
            this.checkBoxMastercard.Location = new System.Drawing.Point(132, 253);
            this.checkBoxMastercard.Name = "checkBoxMastercard";
            this.checkBoxMastercard.Size = new System.Drawing.Size(97, 20);
            this.checkBoxMastercard.TabIndex = 2;
            this.checkBoxMastercard.Text = "Mastercard";
            this.checkBoxMastercard.UseVisualStyleBackColor = true;
            // 
            // LTarjeta
            // 
            this.LTarjeta.AutoSize = true;
            this.LTarjeta.Location = new System.Drawing.Point(12, 194);
            this.LTarjeta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LTarjeta.Name = "LTarjeta";
            this.LTarjeta.Size = new System.Drawing.Size(113, 16);
            this.LTarjeta.TabIndex = 0;
            this.LTarjeta.Text = "Tarjeta de credito";
            // 
            // LDni
            // 
            this.LDni.AutoSize = true;
            this.LDni.Location = new System.Drawing.Point(6, 91);
            this.LDni.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LDni.Name = "LDni";
            this.LDni.Size = new System.Drawing.Size(30, 16);
            this.LDni.TabIndex = 0;
            this.LDni.Text = "DNI";
            // 
            // LNombre
            // 
            this.LNombre.AutoSize = true;
            this.LNombre.Location = new System.Drawing.Point(6, 128);
            this.LNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LNombre.Name = "LNombre";
            this.LNombre.Size = new System.Drawing.Size(56, 16);
            this.LNombre.TabIndex = 1;
            this.LNombre.Text = "Nombre";
            // 
            // LApellido
            // 
            this.LApellido.AutoSize = true;
            this.LApellido.Location = new System.Drawing.Point(6, 164);
            this.LApellido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LApellido.Name = "LApellido";
            this.LApellido.Size = new System.Drawing.Size(57, 16);
            this.LApellido.TabIndex = 2;
            this.LApellido.Text = "Apellido";
            // 
            // LNya
            // 
            this.LNya.AutoSize = true;
            this.LNya.Location = new System.Drawing.Point(6, 38);
            this.LNya.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LNya.Name = "LNya";
            this.LNya.Size = new System.Drawing.Size(119, 16);
            this.LNya.TabIndex = 3;
            this.LNya.Text = "Nombre y Apellido";
            // 
            // LModificar
            // 
            this.LModificar.AutoSize = true;
            this.LModificar.ForeColor = System.Drawing.Color.Red;
            this.LModificar.Location = new System.Drawing.Point(218, 38);
            this.LModificar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LModificar.Name = "LModificar";
            this.LModificar.Size = new System.Drawing.Size(62, 16);
            this.LModificar.TabIndex = 4;
            this.LModificar.Text = "Modificar";
            // 
            // TDni
            // 
            this.TDni.Location = new System.Drawing.Point(81, 88);
            this.TDni.Margin = new System.Windows.Forms.Padding(4);
            this.TDni.Name = "TDni";
            this.TDni.Size = new System.Drawing.Size(199, 22);
            this.TDni.TabIndex = 5;
            this.TDni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TDni_KeyPress);
            // 
            // TApellido
            // 
            this.TApellido.Location = new System.Drawing.Point(81, 161);
            this.TApellido.Margin = new System.Windows.Forms.Padding(4);
            this.TApellido.Name = "TApellido";
            this.TApellido.Size = new System.Drawing.Size(199, 22);
            this.TApellido.TabIndex = 7;
            this.TApellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TApellido_KeyPress);
            // 
            // TNombre
            // 
            this.TNombre.Location = new System.Drawing.Point(81, 125);
            this.TNombre.Margin = new System.Windows.Forms.Padding(4);
            this.TNombre.Name = "TNombre";
            this.TNombre.Size = new System.Drawing.Size(199, 22);
            this.TNombre.TabIndex = 6;
            this.TNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TNombre_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.TDni);
            this.panel1.Controls.Add(this.LNya);
            this.panel1.Controls.Add(this.LApellido);
            this.panel1.Controls.Add(this.LModificar);
            this.panel1.Controls.Add(this.TApellido);
            this.panel1.Controls.Add(this.LTarjeta);
            this.panel1.Controls.Add(this.LNombre);
            this.panel1.Controls.Add(this.checkBoxNaranja);
            this.panel1.Controls.Add(this.checkBoxVisa);
            this.panel1.Controls.Add(this.TNombre);
            this.panel1.Controls.Add(this.checkBoxMastercard);
            this.panel1.Controls.Add(this.LDni);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(367, 285);
            this.panel1.TabIndex = 10;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(408, 162);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(77, 20);
            this.radioButton1.TabIndex = 12;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Hombre";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(408, 188);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(61, 20);
            this.radioButton2.TabIndex = 13;
            this.radioButton2.Text = "Mujer";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Image = global::practico3.Properties.Resources.salir__1_;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(385, 304);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 67);
            this.button1.TabIndex = 14;
            this.button1.Text = "Salir";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::practico3.Properties.Resources.user__1_;
            this.pictureBox1.Location = new System.Drawing.Point(408, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 91);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // TGuardar
            // 
            this.TGuardar.Image = global::practico3.Properties.Resources.save3;
            this.TGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TGuardar.Location = new System.Drawing.Point(13, 304);
            this.TGuardar.Margin = new System.Windows.Forms.Padding(4);
            this.TGuardar.Name = "TGuardar";
            this.TGuardar.Size = new System.Drawing.Size(134, 67);
            this.TGuardar.TabIndex = 8;
            this.TGuardar.Text = "Guardar";
            this.TGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TGuardar.UseVisualStyleBackColor = true;
            this.TGuardar.Click += new System.EventHandler(this.TGuardar_Click);
            // 
            // TEliminar
            // 
            this.TEliminar.Image = global::practico3.Properties.Resources.delete3;
            this.TEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TEliminar.Location = new System.Drawing.Point(192, 304);
            this.TEliminar.Margin = new System.Windows.Forms.Padding(4);
            this.TEliminar.Name = "TEliminar";
            this.TEliminar.Size = new System.Drawing.Size(132, 67);
            this.TEliminar.TabIndex = 9;
            this.TEliminar.Text = "Eliminar";
            this.TEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TEliminar.UseVisualStyleBackColor = true;
            this.TEliminar.Click += new System.EventHandler(this.TEliminar_Click);
            // 
            // PequeñoFormulario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 393);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TGuardar);
            this.Controls.Add(this.TEliminar);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PequeñoFormulario";
            this.Text = "PequeñoFormulario";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button button1;
    }
}

