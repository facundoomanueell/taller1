﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.KeyDown += new KeyEventHandler(this.Form1_KeyDown); // Configurar el evento KeyDown
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //2)Cambie la leyenda del Windows forms con el nombre de “Mi Primer Forms” desde la barra de propiedades y con las dimensiones de 500; 300.
            // *decidi utilizar this para que no sea necesario crear una nueva 
            this.ClientSize = new System.Drawing.Size(500, 300);
            this.Text = "Mi Primer Forms";
        }

        private void BGuardar_Click(object sender, EventArgs e)
        {
            // Concatenar el texto de los TextBox
            string apellido = this.textBox1.Text; // Suponiendo que textBox1 es para Apellido
            string nombre = this.textBox2.Text;   // Suponiendo que textBox2 es para Nombre

            // Mostrar la concatenación en el tercer TextBox
            this.textBox3.Text = apellido + " " + nombre;
        }

        private void BEliminar_Click(object sender, EventArgs e)
        {
            this.textBox3.Clear(); // Suponiendo que textBox3 es el TextBox multilinea
        }
       

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // Verificar si se presiona Ctrl + S
            if (e.Control && e.KeyCode == Keys.S)
            {
                Application.Exit();
            }
        }

        private void BCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
